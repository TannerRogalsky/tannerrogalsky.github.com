
! WARNING ! 
-----------

This software is not complete. This is just a preview. Don't expect to find any 
interface consistencies between releases at all. With each release, everything 
you once knew and loved may be brutally murdered. By which I mean removed and/or 
changed.


RUNNING GAMES
-------------

In Windows or other graphical enviroments, just open the .love file you want to 
run with the love binary, such as love.exe. (~^-^)~

In a console, type "love" followed by the relative or absolute path to a directory 
(or archive).

Examples: 

* love mygame.love
* love /home/hax/ultragame

Remember that what you are trying to run at least should contain the file "main.lua".